package Project;

abstract class AnonymousInnerClass {
		   public abstract void display();
		}


		