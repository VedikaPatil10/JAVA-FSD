package selenium.PracticeProject2Phase5;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class App {
    public static void main(String[] args) throws InterruptedException {
        // Register the webdriver =>browser vendor
        WebDriverManager.chromedriver().setup();
        // Creating an object to the object
        WebDriver wd = new ChromeDriver();
        // Maximize the browser
        wd.manage().window().maximize();

        // Go to browser and open this URL
        wd.get("https://www.amazon.in/");

        // Supply any data using CSS selectors
        wd.findElement(By.cssSelector("input#twotabsearchtextbox")).sendKeys("samsung");
        wd.findElement(By.cssSelector("input#nav-search-submit-button")).click();

        // You can also use XPath to locate elements
        // Supply any data using XPath
        wd.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("samsung");
        wd.findElement(By.xpath("//input[@id='nav-search-submit-button']")).click();

        // Close browser
        Thread.sleep(2000);
        wd.close();
    }
}
