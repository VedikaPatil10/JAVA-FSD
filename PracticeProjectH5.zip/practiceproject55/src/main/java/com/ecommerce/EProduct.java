package com.ecommerce;

public class EProduct {

}
