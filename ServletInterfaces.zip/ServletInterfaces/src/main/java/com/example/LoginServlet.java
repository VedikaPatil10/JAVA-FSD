package com.example;


import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Hard-coded correct credentials
        String correctEmail = "example@example.com";
        String correctPassword = "password123";

        if (email.equals(correctEmail) && password.equals(correctPassword)) {
            String dashboardHtml = "<html><head><title>Dashboard</title></head><body>";
            dashboardHtml += "<h2>Welcome to Dashboard!</h2>";
            dashboardHtml += "<a href='LogoutServlet'>Logout</a>";
            dashboardHtml += "</body></html>";

            response.getWriter().println(dashboardHtml);
        } else {
            String errorHtml = "<html><head><title>Error</title></head><body>";
            errorHtml += "<h2>Invalid login credentials. Please try again.</h2>";
            errorHtml += "<a href='index.html'>Back to Login</a>";
            errorHtml += "</body></html>";

            response.getWriter().println(errorHtml);
        }
   // }// TODO Auto-generated method stub
		//doGet(request, response);
}
}
